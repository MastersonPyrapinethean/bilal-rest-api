import React, { CSSProperties, forwardRef } from 'react';

const styles: { [key: string]: CSSProperties } = {
  ".print-details": {
    display: "flex",
    padding: "10px 5px",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  },
  ".print-details h1": { fontSize: "16px", margin: "0", padding: "1px" },
  img: {
    padding: "3px",
    height: "150px",
    width: "130px",
    borderTop: "1px solid black",
    borderBottom: "1px solid black",
    borderLeft: "1px solid black",
    borderRight: "1px solid black"
  },
  ".name": { margin: 5, backgroundColor: "gray", padding: 0, fontSize: 17 },
  ".code": { margin: 0, backgroundColor: "gray", padding: 0, fontSize: 17 },
  ".line": {
    width: "60vw",
    borderTop: "1px solid #000",
    margin: "0",
    padding: "0"
  },
  ".details": {
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    width: "50vw",
    padding: "0"
  },
  ".details p": {
    fontWeight: 600,
    fontSize: "16px",
    padding: "0",
    textDecoration: "underline",
    margin: "0"
  },
  ".details ul,\n.third-para ul": {
    listStyle: "none",
    padding: "0",
    margin: "0",
    fontSize: "13px"
  },
  ".third-para": {
    width: "50vw",
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    marginBottom: "5px"
  },
  ".third-para h3": { textDecoration: "underline", margin: "0", padding: "0" },
  ".third-para ul li": { textDecoration: "underline" },
  ".four-para": {
    width: "50vw",
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    marginBottom: "5px"
  },
  ".four-para h3": { textDecoration: "underline", margin: "3px", padding: "0" },
  ".four-para p": { padding: "0", margin: "3px" },
  ".five-para": {
    width: "50vw",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    padding: "0",
    fontSize: "13px",
    marginBottom: "1px"
  },
  ".last-para": {
    width: "50vw",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center"
  },
  ".last-para a": { fontSize: "11px", padding: "2px", margin: "0" },
  ".last-para h5": { fontSize: "12px", padding: "1px", margin: "0" },
  ".last-para p": { fontSize: "9px", padding: "2px", margin: "0" },
  ".print-btn": {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  },
  ".print-btn button": {
    margin: "10px",
    padding: "5px 8px",
    backgroundColor: "inherit",
    color: "blue",
    borderRadius: "3px",
    fontSize: "18px"
  }
}

const ComponentToPrint = forwardRef<HTMLDivElement, { name: string, code: string, image?: string }>((props, ref) => {
  return (
    <div ref={ref} style={styles['.print-details']}>
      <h1 style={{ fontSize: 21, fontWeight: 'bold' }}> GRADE ONE (Sponsor Certificate Recipt)</h1>
      <p style={{ fontSize: 10, textDecoration: 'underline', padding: 0 }}>This document Grant The CertifyHoldet - Perks Purchased</p>
      <img
        src={props.image ? props.image : 'https://icon-library.com/images/default-profile-icon/default-profile-icon-5.jpg'}
        alt="user"
        style={{
          marginTop: 10,
          objectFit: 'cover',
          height: '150px',
          width: '130px',
        }}
      />
      <h2 style={styles['.name']}>{props.name}</h2>
      <h2 style={styles['.code']}>YAAVAAY: {props.code}</h2>
      <div style={styles['.line']} />
      <div style={styles['.details']}>
        <p style={{ fontSize: 11, fontWeight: 'bold', padding: 0 }}>  This unique passcode permits secure access to the VICE(s) stated below.</p>
        <ul>
          <li>(01) - Lottery drawn participants unique passcode to enter intergalaxtic epiccentre ET handshake.</li>
          <li>(02) - Passcode to access secured channel-LIVE feed on moment of global ExtraTerristial contact.</li>
          <li>(03) - Sponsor(s) registered name to be forged into Giant Iron Tablet for historical commemoration.</li>
          <li>(04) - 10 days daily alert prior contact to collect tailored welcome uniform-space taxi pickup point.</li>
          <li>(05) - Permit access to the front of spacers seated position rim for an absolute unobstructive view.</li>
          <li>(06) - Prebooking residential deposited onto contact platform-spaceport for all future E.T contacts.</li>
          <li>(07) - Ten available return trips from Earth to Off-World visitations with or without Contact success.</li>
        </ul>
      </div>
      <div style={styles['.line']} />
      <div style={styles['.third-para']}>
        <h3>Prior Entry into SpaceTaxi(s) PROTOCAL</h3>
        <ul>
          <li>(01)-Security facial Recognition MATCH</li>
          <li>(02)-Unique Passcode MATCH</li>
          <li>(03)-Identity MATCH</li>
        </ul>
      </div>
      <div style={styles['.line']} />
      <div style={styles['.four-para']}>
        <h3>REFUND STATUS:</h3>
        <h3>LOCAL SPACE TAXIS REJECTION</h3>
        <p>“Sudden Death” refund occur upon individual(s) whom failed the meat-free biological toxin scan.</p>
        <h3>CONTACT PLATFORM CONDITION</h3>
        <p>Refund automated through YAAVAAY failure to accomplish intended products & services agreed.</p>
      </div>
      <div style={styles['.line']} />
      <div style={styles['.five-para']}>
        <p>ALL SPONSORED PARTICIPANTS ARE STRONGLY ADVISED TO HAVE WITHIN THEIR POSSESSION UNIQUE PASSCODE OR CERTIFICATE RECEPT OR BOTH PRIOR ENTRY INTO SPACETAXIS.</p>
      </div>
      <div style={styles['.line']} />
      <div style={styles['.last-para']}>
        <a href="www.yaavaay.com" style={{ fontSize: 13, fontWeight: 'bold' }}>YAAVAAY.com</a>
        <h5 style={{ fontSize: 10 }}>( Earth Only Delibrate Mass Extraterrestrial Public Contact )</h5>
        <p style={{ fontSize: 7 }}>YAAVAAY private contractor(s) research and development inclusive of all intended services are fully responcible for the succession of mass Extraterrestrial contact witnessed and experienced on a global scale. YAAVAAY multifaceted designs to manufactures specific technologies in their delibrated targetted output to engineer with high intensions the appointed invitation of benevolent Off-World entities to demonstrate open contact and integration publicly.</p>
      </div>
    </div>
  );
});

export default ComponentToPrint;
