import React from 'react';
import express, { Express, Request, Response, Application } from 'express';
import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import cors from 'cors';
import { Pool } from 'pg';
import { body, validationResult } from "express-validator";
import multer from 'multer';
import path from 'path';
import * as fs from 'fs';
import Stripe from 'stripe';

import ReactDOMServer from 'react-dom/server';
import ComponentToPrint from './utils/ComponentToPrint';
import generatePDF from './utils/generatePdf';
import sendEmail from './utils/sendEmail';

// For env File 
dotenv.config({ path: path.resolve(__dirname, '/etc/secrets/.env') });

// Initialize Database Connection (PostgreSQL)
const pool = new Pool({
    connectionString: process.env.DB_CON_URL,
    ssl: {
        rejectUnauthorized: false
    }
});

// Initialize stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
    apiVersion: '2023-08-16',
});


const app: Application = express();
app.use(cors());
app.use(bodyParser.json());

const port = process.env.PORT || 8000;

// Used to make health checks
app.get('/', (req: Request, res: Response) => {
    res.send('YAAVAAY - REST-API');
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, '/mnt/image-storage'); // Your Render disk mount path
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});

const upload = multer({ storage });

function generateUniqueCode(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const segments = [2, 4, 4, 4, 4];
    return segments.map(segment => {
        return Array.from({ length: segment }).map(() => chars[Math.floor(Math.random() * chars.length)]).join('');
    }).join('-');
}

// POST endpoint for creating a new user
app.post('/v1/users',
    upload.single('image'),
    [
        body("email").isEmail().withMessage("Invalid email address"),
        body("firstName").notEmpty().withMessage("First name is required"),
        body("lastName").notEmpty().withMessage("Last name is required"),
        body("stripeToken").notEmpty().withMessage("Stripe token is required"),
        body("product").notEmpty().withMessage("Product is required"),
    ],
    async (req: Request, res: Response) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        const { firstName, lastName, email, stripeToken, product } = req.body;
        const imageName = req.file ? req.file.filename : null;

        if (product <= 0 || product > 5) return res.status(400).json({ message: "Product invalid (1-5)" }); 

        try {
            // Check if email is already taken
            const emailCheckQuery = "SELECT * FROM users WHERE email = $1";
            const result = await pool.query(emailCheckQuery, [email]);
            if (result.rows.length > 0) return res.status(400).json({ message: "Email already taken" });

            // Create Stripe charge
            let amount = 100; // Amount in cents
            let description = 'Product description';

            if (product === 1) {
                amount = 10000;
                description = 'Product 1 description.'
            }
            else if (product === 2) {
                amount = 100000;
                description = 'Product 2 description.'
            }
            else if (product === 3) {
                amount = 1000000;
                description = 'Product 3 description.'
            }
            else if (product === 4) {
                amount = 10000000;
                description = 'Product 4 description.'
            }
            else if (product === 5) {
                amount = 100000000;
                description = 'Product 5 description.'
            }
            const charge = await stripe.charges.create({
                amount: amount,
                currency: "usd",
                source: stripeToken,
                description: description,
                receipt_email: email,
            });

            // Confirm the payment was successful
            if (charge.status === "succeeded") {
                // Generated unique code
                const uniqueCodeGenerated: string = generateUniqueCode();

                // Insert user into database
                const { rows } = await pool.query('INSERT INTO users (first_name, last_name, email, avatar) VALUES ($1, $2, $3, $4) RETURNING id, first_name, last_name, email, avatar', [firstName, lastName, email, imageName]);

                // Convert the image to base64
                const fileToBase64 = (file: Express.Multer.File): string => {
                    const fileData = fs.readFileSync(file.path);
                    return `data:${file.mimetype};base64,${fileData.toString('base64')}`;
                };

                const base64ImageString = req.file ? fileToBase64(req.file) : undefined;

                // Generate receipt and send it through user email
                const htmlString = ReactDOMServer.renderToStaticMarkup(
                    <ComponentToPrint name={`${firstName} ${lastName}`} code={uniqueCodeGenerated} image={base64ImageString} />
                );

                const pdfBuffer = await generatePDF(htmlString);
                await sendEmail(email, pdfBuffer);

                // Return success status
                res.status(201).json({
                    message: 'User created successfully',
                    user: rows[0],
                });
                return;
            } else {
                res.status(400).json({ error: "Payment failed" });
                return;
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    });

// GET endpoint to serve images
app.get('/v1/images/:imageName', (req: Request, res: Response) => {
    const imageName = req.params.imageName;
    const imagePath = path.join('/mnt/image-storage', imageName); // Your Render disk mount path

    res.sendFile(imagePath, (err) => {
        if (err) {
            res.status(404).json({ error: "Image not found" });
        }
    });
});


app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
